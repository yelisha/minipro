package unittests;

import geometries.*;
import org.junit.Test;
import primitives.*;
import static org.junit.Assert.assertEquals;

public class PlaneTest
{
    @Test
   public void get_normal()
    {
        // ============ Equivalence Partitions Tests ==============
        // TC01: There is a simple single test here
        Plane p=new Plane(new Point3D(1, 2, 3), new Vector(new Point3D(1, 0, 0)));
        Vector v=new Vector(new Point3D(1, 0, 0));
        double d= p.getNormal(new Point3D(1, 2, 3)).length();

        assertEquals("Wrong normal for plan",v,p.get_normal()) ;
        // assertEquals("Wrong normal to plane", new Vector(new Point3D(1, 0, 0)), p.getNormal(new Point3D(1, 2, 3)));

    }
}



package unittests;

import geometries.Polygon;
import geometries.Triangle;
import org.junit.Assert;
import org.junit.Test;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;
import java.util.List;
import static org.junit.Assert.assertEquals;
/**
 * Testing Polygons
 * @author Dan
 *
 */
public class PolygonTest {


    @Test
    public void testConstructor()
    {
        // ============ Equivalence Partitions Tests ==============

        // TC01: Correct concave quadrangular with vertices in correct order
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0),
                    new Point3D(0, 1, 0), new Point3D(-1, 1, 1));
        } catch (IllegalArgumentException e)
        {
            Assert.fail("Failed constructing a correct polygon");

        }

        // TC02: Wrong vertices order
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(0, 1, 0),
                    new Point3D(1, 0, 0), new Point3D(-1, 1, 1));
            Assert.fail("Constructed a polygon with wrong order of vertices");
        } catch (IllegalArgumentException e) {}

        // TC03: Not in the same plane
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0),
                    new Point3D(0, 1, 0), new Point3D(0, 2, 2));
            Assert.fail("Constructed a polygon with vertices that are not in the same plane");
        } catch (IllegalArgumentException e) {}

        // TC04: Concave quadrangular
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0),
                    new Point3D(0, 1, 0), new Point3D(0.5, 0.25, 0.5));
            Assert.fail("Constructed a concave polygon");
        } catch (IllegalArgumentException e) {}

        // =============== Boundary Values Tests ==================

        // TC10: Vertix on a side of a quadrangular
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0),
                    new Point3D(0, 1, 0), new Point3D(0, 0.5, 0.5));
            Assert.fail("Constructed a polygon with vertix on a side");
        } catch (IllegalArgumentException e) {}

        // TC11: Last point = first point
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0),
                    new Point3D(0, 1, 0), new Point3D(0, 0, 1));
            Assert.fail("Constructed a polygon with vertice on a side");
        } catch (IllegalArgumentException e) {}

        // TC12: Collocated points
        try {
            new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0),
                    new Point3D(0, 1, 0), new Point3D(0, 1, 0));
            Assert.fail("Constructed a polygon with vertice on a side");
        } catch (IllegalArgumentException e) {}

    }

    /**
     * Test method for {@link geometries.Polygon#getNormal(primitives.Point3D)}.
     */
    @Test
    public void testGetNormal() {
        // ============ Equivalence Partitions Tests ==============
        // TC01: There is a simple single test here
        Polygon pl = new Polygon(new Point3D(0, 0, 1), new Point3D(1, 0, 0), new Point3D(0, 1, 0),
                new Point3D(-1, 1, 1));
        double sqrt3 = Math.sqrt(1d / 3);
        assertEquals("Bad normal to triangle", new Vector(sqrt3, sqrt3, sqrt3), pl.getNormal(new Point3D(0, 0, 1)));
    }

   public void findIntersections()
    {
      //  ============ Equivalence Partitions Tests ==============
       Point3D p1 = new Point3D(-4.56005, -3.50549, 0);
       Point3D p2 = new Point3D(-4.94874, -1.13317, 0);
       Point3D p3 = new Point3D(-6.20823, -5.73221, 0);
       Triangle t=new Triangle(p1,p2,p3);
       Point3D rp = new Point3D(-4.08359, -4.64808, 0);
       Ray r=new Ray(new Vector(-1.27,0.99,0),rp);

       List<Point3D> exp = List.of(new Point3D(-5.35,-3.66,0));

       // TC01: Ray's line is Inside triangle (1 point)
       assertEquals("Ray's line Inside triangle",exp,t.findIntersections(new Ray(new Vector(-1.27,0.99,0),new Point3D(-4.08359, -4.64808, 0))));
/*
        Point3D p1 = new Point3D(1,0,0);
        Point3D p2 = new Point3D(3,0,0);
        Point3D p3 = new Point3D(2,0,1);
        Triangle t=new Triangle(p1,p2,p3);
        Point3D rp = new Point3D(1,0,1);
        Ray r=new Ray(new Vector(0,0,-1),rp);

        List<Point3D> exp = List.of(new Point3D(1,0,0));
        // assertEquals("Ray's line Inside triangle",6,6);
       */
    }
}


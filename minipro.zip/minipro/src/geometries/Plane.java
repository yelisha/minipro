package geometries;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

import java.util.List;
/**
 *
 * @author Liel Lugasi 211327804, Yael Elisha 207486358
 *
 */

public class Plane
{
    /**
     * class Plane contains point3d and normal vector
     */
    Point3D _p;
    Vector _normal;
    /**
     * ctor with 3 point3d parameters
     * @param p1
     * @param p2
     * @param p3
     */
    public Plane(Point3D p1,Point3D p2,Point3D p3)
    {
        _p=p1;
        _normal=null;

    }
    /**
     * ctor with 1 Point3D and 1 Vector parameters
     * @param p
     * @param n
     */
    public Plane(Point3D p,Vector n)
    {
        _p=p;
        _normal=n;
    }
    /**
     *
     * @return Point3D
     */
    public Point3D get_p() {
        return _p;
    }
    /**
     *
     * @return Vector
     */
    public Vector get_normal() {
        return _normal;
    }
    /**
     * meanwhile doesn't in use
     * @param point
     * @return null
     */
    public Vector getNormal(Point3D point)
    {
        return _normal.normalized();
    }
    /**
     * meanwhile doesn't in use
     * @return nO
     */
    public Vector getNormal()
    {
        return _normal;
    }
    public List<Point3D> findIntersections(Ray ray) {
       /* Vector p0Q;
        try {
            p0Q = _p.subtract(ray.getP());
        } catch (IllegalArgumentException e) {
            return null; // ray starts from point Q - no intersections
        }

        double nv = _normal.dotProduct(ray.getV());
        if (isZero(nv)) // ray is parallel to the plane - no intersections
            return null;

        double t = alignZero(_normal.dotProduct(p0Q) / nv);


        if ( t > 0)
        {
            Intersectable.Point3D geo  = new Point3D(this,ray.getTargetPoint(t));
            return  List.of(p);
        }
        else
            return null;
    }
*/
        return null;
}


}
